from django.apps import AppConfig


class HumansensingConfig(AppConfig):
    name = 'HumanSensing'
